# Ejecutando Liquibase con Oracle en Docker

Este proyecto utiliza: 
- Liquibase para gestionar los cambios en el esquema de una base de datos Oracle.
- Docker y docker compose version 26.0 o superior
  (si lo desea puede bajar docker desktop)
- Maven 3.5 o superior
- Java 17 o superior

## Requisitos previos:

Docker y Docker-compose, instalado y en ejecución.

## Configuración:

Archivo ./docker/.env:

Define las siguientes variables de entorno con los valores correspondientes:
    SCHEMA: El nombre del esquema que se creará en la base de datos.
    PASSWORD: La contraseña para el usuario del esquema.


## Ejecución:

Iniciar el contenedor Docker:
Abre una terminal en el directorio raíz del proyecto.

Ejecuta el siguiente comando:

```bash
./docker/start.sh
```

## Estructura del directorio del proyecto

- **Archivos de Propiedades**:
  - **liquibase-init.properties**: Documento cuya función es definir la conexion a la base de datos donde se va a trabajar. Además de establecer la estructura inicial de la base de datos, abarca aspectos como esquemas, usuarios, permisos y tablespace.
  - **liquibase-schema.properties**: Documento cuya función define la conexion a la base de datos donde se va a trabajar. Adicional, se define el esquema donde se van a generar los objetos, como son tablas e indices.
- **Carpeta changelog**:
  En esta carpeta se colocan archivos con extension xml. Está dividido en dos carpetas principales: DDL, que contiene todos los cambios relacionados con grants, índices, tablas, tablespaces, etc.; y la carpeta DML, que se centra en la carga de información en tablas para catalogos
- **Carpeta master-changelog**:
  En esta carpeta se colocan archivos de tipo xml, estos archivos engloban todos los cambios que se impactaran en la base de datos. El archivo master-changelog-init.xml contiene las instrucciones para inicializar la base de datos, incluyendo la creación de usuarios, permisos y tablespaces. Por otro lado, el archivo master-changelog-{escenario}.xml agrupa las instrucciones para la generación de objetos en la base de datos, tales como tablas e índices.
- **Carpeta upload-data**:
  Esta carpeta contiene archivos CSV que contienen la información a cargar en las tablas creadas. Específicamente para este proyecto, se planea llenar las tablas tipo catálogos desde aquí..

A continuacón mostraremos la estructura del proyecto:
```
src
└── main
   └── resources
       └── db
           └──schema
           │    └──changelog
           │    │   ├──DDL
           │    │   │   ├─constraints
           │    │   │   │  └── *.xml              
           │    │   │   ├─grants
           │    │   │   │  └── *.xml         
           │    │   │   ├─index
           │    │   │   │  └── *.xml  
           │    │   │   ├─tables
           │    │   │   │  └── *.xml         
           │    │   │   ├─tablespace
           │    │   │   │  └── *.xml  
           │    │   │   └─users
           │    │   │      └── *.xml     
           │    │   └──DML
           │    │       └── *.xml
           │    ├── master-changelog
           │    │     ├── master-changelog-schema.xml
           │    │     └── master-changelog-init.xml
           │    └── upload-data  
           │        └──*.csv
           ├── liquibase-init.properties
           └── liquibase-schema.properties
```


## Ejecutar los comandos de Liquibase:

**Una vez que el contenedor esté en ejecución, puedes ejecutar los comandos de Liquibase usando Maven:**

-Para cargar la configuración inicial deberas ejecutar el siguiente comando:

```bash
mvn liquibase:update
```
Este comando tomara todos los cambios alojados en el achivo master-changelog-init.xml, y los impactara en la base de datos.

-Una vez que se ejecuto de manera correcta la primera fase (creación de usuarios, permisos,etc), se ejecuta el siguiente comando para poder generar tablas, e indices.

**Importante:** Asegurate de definir en el properties liquibase-schema.properties, el password, user y esquema donde vas a impactar los objetos 

```bash
mvn liquibase:update -Pload-schema -Dtest-scenario=schema
```
-Para ver el estado actual de la base de datos y los cambios pendientes.

```bash
mvn liquibase:status
```
-Para revertir los cambios aplicados a la base de datos indicando el numero de saltos que queremos revertir, donde el numero es igual al numero de pasos que queremos revertir

```bash
mvn liquibase:rollback -D liquibase.rollbackCount=1
```
-Para revertir los cambios aplicados a la base de datos con un tag.    
-**Importante**: el rollback debe aplicarse al perfil y al escenario indicado, el ejemplo de abajo indica que el rollback se aplicara al esquema principal 

```bash
mvn liquibase:rollback -D liquibase.rollbackTag=1.1.1
```

-A continuación se muestra un ejemplo de como hacer un rollback con tag, definiciendo el perfil (-P) y el escenario (-D)

```bash
mvn liquibase:rollback -P load-schema -D liquibase.rollbackTag=1.1.1 -Dtest-scenario=schema
```

-Para generar el historico de migraciones, de la conexion actual de liquibase.

```bash
mvn liquibase:generateChangeLog -Dliquibase.outputChangeLogFile=src/main/resources/migration_history.oracle.sql
```
## Comparar entre 2 bases de datos
-Para generar el detalle de cambios de la comparación de las bases de datos con la base de datos de destino
### Configuracion 
```liquibase.properties
    url=jdbc:oracle:thin:@localhost:1521:xe?currentSchema=NCC-QA
    username=NCC-QA
    password=Adm1n2024
    driver=oracle.jdbc.OracleDriver

    referenceDriver: oracle.jdbc.OracleDriver
    referenceUrl: jdbc:oracle:thin:@localhost:1521:xe?currentSchema=NCC
    referenceUsername:NCC
    referencePassword:Adm1n2024
```

### Ejecutar los siguientes comandos 
-Para generar el detalle con los cambios de la comparación de las bases de datos con la base de datos de destino.

```bash
mvn liquibase:diff -Dliquibase.outputFile=src/main/resources/diff-migration_history.txt 
```
-Para generar las sentencias sql con los cambios de la comparación de las bases de datos con la base de datos de destino.

```bash
mvn liquibase:diff -Dliquibase.diffChangeLogFile=src/main/resources/diff-migration_history.oracle.sql
```
liquibase rollbackOneChangeSet --changeSetId=LOAD-LOAN-BALANCE-DETAIL --changeSetAuthor=admin --changeSetPath=0003-loan-load-data-loan-balance.xml --force