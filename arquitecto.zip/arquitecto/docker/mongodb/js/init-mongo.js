db = db.getSiblingDB("test");
db.createUser({
  user: "adminTest",
  pwd: "Adm1nT3st",
  roles: [
    { role: "readWrite", db: "test" },
    { role: "dbAdmin", db: "test" },
    { role: "userAdmin", db: "test" }
  ]
});
