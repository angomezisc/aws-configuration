#!/bin/bash

DIR=$(dirname "$(readlink -f "$0")")
BASE_DIR=$(dirname "$DIR")
ENV_FILE=${DIR}/.env
TEMPLATE_FILE=${DIR}/docker-compose-template.txt
DOCKER_COMPOSE_FILE=${DIR}/docker-compose.yml

PROPERTIES_FILE_NAME=${BASE_DIR}/src/main/resources/db/liquibase-schema.properties

if [ ! -f "$PROPERTIES_FILE_NAME" ]; then
  echo "Archivo de propiedades $PROPERTIES_FILE_NAME no encontrado."
  exit 1
fi

DRIVER=`echo $(grep -i "^driver=" "$PROPERTIES_FILE_NAME") | awk -F"=" '{print $2}' | awk -F"." '{print $NF}'`

echo "Driver encontrado -> ${DRIVER}"

case "$DRIVER" in
    OracleDriver)
    DATABASE=ORACLE        
    ENVIROMENTS=`grep ${DATABASE} ${ENV_FILE} | sed -e "s/${DATABASE}_//"`
    export ${ENVIROMENTS}
        
        ;;
    MongoClientDriver)
    DATABASE=MONGODB        
    ENVIROMENTS=`grep ${DATABASE} ${ENV_FILE} | sed -e "s/${DATABASE}_//"`
    export ${ENVIROMENTS}    
    
        ;;
    *)
        echo "Base de datos no soportada: $DRIVER"
        echo "Bases de datos soportadas: [oracle, mongodb]"
        exit 1
        ;;
esac

echo "Creating services"
docker-compose --profile ${DATABASE} -f docker/docker-compose.yml up --no-recreate -d --remove-orphans